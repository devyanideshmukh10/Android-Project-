package com.example.android.devyani.Model;

import com.parse.ParseClassName;
import com.parse.ParseObject;

/**
 * Created by Sanket on 4/2/2017.
 */

@ParseClassName("area")
public class Area extends ParseObject {
    public Area(String theClassName) {
        super(theClassName);
    }

    public Area() {
    }
}
